SELECT * FROM Student
WHERE age > 18;