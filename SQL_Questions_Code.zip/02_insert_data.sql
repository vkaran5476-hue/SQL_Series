INSERT INTO Student (student_id, name, age, course)
VALUES (1, 'Karan', 20, 'B.Tech');