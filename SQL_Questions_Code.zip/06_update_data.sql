UPDATE Student
SET course = 'BCA'
WHERE student_id = 1;