DELETE FROM Student
WHERE student_id = 1;