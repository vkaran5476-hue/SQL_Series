SELECT s.student_id, s.name, c.course_name
FROM Student s
INNER JOIN Course c
ON s.course = c.course_name;