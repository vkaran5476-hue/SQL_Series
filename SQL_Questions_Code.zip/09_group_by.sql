SELECT course, COUNT(*) AS total
FROM Student
GROUP BY course;